﻿=== Dabomb's Runescape (Fantasy) Cursor Set ===

By: Dabomb10100 (http://www.rw-designer.com/user/2275) ycguo111@yahoo.com

Download: http://www.rw-designer.com/cursor-set/fake-rs-items

Author's description:

A group of fake items i created :D

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.