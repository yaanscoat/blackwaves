﻿=== 4LEAF Cursor Set ===

By: THTH

Download: https://www.rw-designer.com/cursor-set/4leaf

Author's description:

Cursores del juego 4LEAF, lanzado en el año 2000.
Juego de chat y comunidad online 2D con estética anime: interactuás en una vibrante plataforma social basada en el universo literario de Rune's Children, destacando por sus salas temáticas de chat interactivo y el adictivo minijuego de tablero táctico Dice of Destiny, sumado a un sistema de avatares personalizables que sirvió como antesala y base para el nacimiento del clásico MMORPG Tales Weaver.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.