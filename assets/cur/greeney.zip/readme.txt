﻿=== Greeny Cursor Set ===

By: Kizzume (http://www.rw-designer.com/user/1697) kizzume1973@harbornet.com

Download: http://www.rw-designer.com/cursor-set/greeney

Author's description:

A nice green cursor set.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.