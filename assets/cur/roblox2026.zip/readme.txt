﻿=== Roblox 2026 Cursor Set ===

By: blub

Download: https://www.rw-designer.com/cursor-set/roblox2026

Author's description:

just a few cursors and icons i ripped from the 2026L (newest) client, mainly uploaded here for archival purposes

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.