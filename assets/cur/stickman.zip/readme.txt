﻿=== StickDude Cursor Set ===

By: Mr. Zidgel (http://www.rw-designer.com/user/1915) z349dilman@gmail.com

Download: http://www.rw-designer.com/cursor-set/stickman

Author's description:

Watch it be stupid with a movie!
---------------------------------
StickMan 2 Cursor Movie is comin' up!!!


==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.